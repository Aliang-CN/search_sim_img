"""
 @Author: Aliang
 @Email: linxingliang@stary.com
 @FileName: milvus_handle.py
 @DateTime: 2022/10/9 下午5:33
 @SoftWare: PyCharm
"""

import random
from milvus import Milvus, IndexType, MetricType, Status
import logging

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
logging.basicConfig(level=logging.DEBUG, format=LOG_FORMAT)


class MilvusHandle(object):
    def __init__(self, host, port, collection_name):
        self.collection_name = collection_name
        self.milvus = Milvus(host, port)
        self.create_collection()

    def create_collection(self):
        status, ok = self.milvus.has_collection(self.collection_name)
        if not ok:
            param = {
                'collection_name': self.collection_name,
                'dimension': 1000,
                'index_file_size': 32,                                  # optional
                'metric_type': MetricType.L2                            # optional
            }
            self.milvus.create_collection(param)
        _, collection = self.milvus.get_collection_info(self.collection_name)
        logging.info(collection)
        return ok

    def list_collections(self):
        _, collections = self.milvus.list_collections()
        logging.debug(collections)
        return collections

    def get_info(self):
        _, collection = self.milvus.get_collection_info(self.collection_name)
        logging.info(collection)
        return collection

    def insert(self, vectors):
        status, ids = self.milvus.insert(collection_name=self.collection_name, records=vectors)
        if not status.OK():
            logging.info("Insert failed: {}".format(status))
        self.milvus.flush([self.collection_name])
        return ids

    def get_row_count(self):
        status, result = self.milvus.count_entities(self.collection_name)
        logging.info("Creating index: {}".format(result))
        return result

    def search_by_ids(self, ids, top_k):
        vectors = self.get_entity_by_id(ids)
        results = self.search(vectors, top_k)
        return results

    def search(self, query_vectors, top_k):
        search_param = {
            "nprobe": 16
        }
        param = {
            'collection_name': self.collection_name,
            'query_records': query_vectors,
            'top_k': top_k,
            'params': search_param,
        }

        status, results = self.milvus.search(**param)
        if status.OK():
            logging.debug(results)
        else:
            logging.error("Search failed. ", status)
        return results

    def drop_collection(self):
        status = self.milvus.drop_collection(self.collection_name)
        if status.OK():
            logging.info('drop collection done !!!')
        return status

    def get_collection_info(self):
        _, collection = self.milvus.get_collection_info(self.collection_name)
        logging.info(collection)
        return collection

    def get_entity_by_id(self, index_list):
        status, result_vectors = self.milvus.get_entity_by_id(self.collection_name, index_list)
        logging.debug('result_vectors:   ', result_vectors)
        return result_vectors

    @property
    def get_index_info(self):
        status, index = self.milvus.get_index_info(self.collection_name)
        return index
