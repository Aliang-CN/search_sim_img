# !/usr/bin/env python
# -*-coding:utf-8 -*-

"""
# File       : faiss_handle.py
# Time       ：2022/11/15 下午4:29
# Author     ：Aliang
# Description：
"""

